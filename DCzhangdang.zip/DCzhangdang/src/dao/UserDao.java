package dao;

import entity.Config;
import entity.User;
import util.DBUtil;
import util.DateUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UserDao {
    private static final String USER_SQL = "SELECT * FROM User WHERE user=? and password= ?";
    private static final String USER_SQL_user = "SELECT * FROM User WHERE user= ?";
    private static final String USER_SQL_ADD = "INSERT INTO User VALUES(?,?,?,?,default)";
    private static final String USER_SQL_DEL = "DELETE FROM User  WHERE user = ?";
    private static final String USER_SQL_CHANGE = "UPDATE User SET password=? WHERE User=?";
    private static final String USER_ ="SELECT user,password FROM User";
    
    public static User getUserALL( String user,String password){
        try {
            User user1=null;
            Connection conn = DBUtil.getConnection();
            Statement state = conn.createStatement();
            PreparedStatement prep = conn.prepareStatement(USER_SQL);
            prep.setString(1,user);
            prep.setString(2,password);
            ResultSet rs = prep.executeQuery();
            if(rs.next()){
                user1 = new User();
                user1.setId(rs.getInt("id"));
                user1.setUser(rs.getString("user"));
                user1.setPassword(rs.getString("password"));
                user1.setLog(rs.getString("log"));
                user1.setLv(rs.getString("lv"));
            }


            return user1;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
    }
    public static Boolean getUsername(String user) {
        try {
            Connection conn = DBUtil.getConnection();
            Statement state = conn.createStatement();
            PreparedStatement prep = conn.prepareStatement(USER_SQL_user);
            prep.setString(1,user);
            ResultSet rs = prep.executeQuery();
            String user1=null;
            if(rs.next()){
                 user1 = rs.getString("user");

            }
            return user1!=null;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }

    }
    public static Boolean add(String user,String password) {
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement prep = conn.prepareStatement(USER_SQL_ADD);
            prep.setString(1,user);
            prep.setString(2,password);
                prep.setString(3,"2");
            prep.setString(4, String.valueOf(DateUtil.util2sql(DateUtil.today())));
            int i = prep.executeUpdate();
            if (i==0){
                return false;
            }else {
                return true;
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }
    public static Boolean del(String user)  {
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement prep = conn.prepareStatement(USER_SQL_DEL);
            prep.setString(1,user);
            int i = prep.executeUpdate();
            if (i==0){
                return false;
            }else {
                return true;
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }
    public static boolean change(String password,String user)  {
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement prep = conn.prepareStatement(USER_SQL_CHANGE);
            prep.setString(1,password);
            prep.setString(2,user);
            int i = prep.executeUpdate();
            if (i==0){
                return false;
            }else {
                return true;
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }
    public static List<User> all()  {
        List<User> list = new ArrayList<>();
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement prep = conn.prepareStatement(USER_);
            ResultSet resultSet = prep.executeQuery();
            while (resultSet.next()){
                User user = new User();
                user.setUser(resultSet.getString("user"));
                user.setPassword(resultSet.getString("password"));
                list.add(user);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return list;
    }




    public static void main(String[] args) throws SQLException {
//        Boolean username = new UserDao().getUsername("admin1");
//        System.out.println(username);
//
//        User admin = new UserDao().getUserALL("admin", "123456");
//        System.out.println(admin.getId());

//        Boolean admin1 = new UserDao().add("admin1", "123456");
//        System.out.println(admin1);
//
//        boolean admin12= new UserDao().change("123321", "admin12");
//        System.out.println(admin12);
//
//        Boolean admin11 = new UserDao().del("admin1");
//        System.out.println(admin11);
        List<User> all = UserDao.all();
        System.out.println(Arrays.toString(all.toArray()));

    }
}
