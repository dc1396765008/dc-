package gui.listener;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;

import dao.CategoryDAO;
import dao.ConfigDAO;
import dao.RecordDAO;
import dao.UserDao;
import entity.Category;
import entity.User;
import gui.panel.BackupPanel;
import gui.panel.ConfigPanel;
import gui.panel.MainPanel;
import service.ConfigService;
import util.MysqlUtil;

public class BackupListener implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		BackupPanel b = BackupPanel.instance;

		JButton button = (JButton)e.getSource();
		if(button == b.bAdd){
			//���������ʽ

			String name = JOptionPane.showInputDialog("�����˺�");
			String pass =null;
			if(0 == name.length()){
				JOptionPane.showMessageDialog(b, "�˺����Ʋ���Ϊ��");
				return;
			}
			Boolean username = UserDao.getUsername(name);
			if (username){
				JOptionPane.showMessageDialog(b, "�˺��Ѿ�����");
				return;
			}
			if (name!=null){
				pass = JOptionPane.showInputDialog("��������");
				if(0 == pass.length()){
					JOptionPane.showMessageDialog(b, "�������Ʋ���Ϊ��");
					return;
				}
				if (pass==null){
					name=null;

				}
			}



			Boolean add = UserDao.add(name, pass);
			System.out.println(add);


		}
		if(button == b.bEdit){
			User c = b.getSelectUser();
			/*********************/
			String name = JOptionPane.showInputDialog("�޸�����",c.getPassword());
			if(0 == name.length()){
				JOptionPane.showMessageDialog(b, "���벻��Ϊ��");
				return;
			}
			UserDao.change(name,c.getUser());

		}
		if (button==b.bDelete){
			User c = b.getSelectUser();
			if(c.getUser().equals("admin")){
				JOptionPane.showMessageDialog(b, "���˺��ǹ���Ա,����ɾ��");
				return;
			}
			if (JOptionPane.OK_OPTION != JOptionPane.showConfirmDialog(b, "ȷ��Ҫɾ����"))
				return;
			UserDao.del(c.getUser());
			RecordDAO.del(c.getUser());
			ConfigDAO.del(c.getUser());
			CategoryDAO.del(c.getUser());
		}
		b.updateDate();
	}
	

}
