package gui.panel;
/**
 * ���ݽ���
 */

import javax.swing.*;
import javax.swing.table.TableModel;

import dao.UserDao;
import entity.Category;
import entity.User;
import gui.listener.BackupListener;
import gui.listener.CategoryListener;
import gui.model.BackupTableModel;
import gui.model.CategoryTableModel;
import service.CategoryService;
import util.ColorUtil;
import util.GUIUtil;

import java.awt.*;

public class BackupPanel extends WorkingPanel{

	private static final long serialVersionUID = 1L;
	
	static{
		GUIUtil.useLNF();
	}
	
	public static BackupPanel instance  = new BackupPanel();



	public JButton bAdd = new JButton("����");
	public JButton bEdit = new JButton("�༭");
	public JButton bDelete = new JButton("ɾ��");
	String colunmNames[]  =  new String[]{"�˺�����","�˺�����"};
	public BackupTableModel ctm = new BackupTableModel(colunmNames, UserDao.all());
	public JTable t = new JTable(ctm);
	
	private BackupPanel(){
		GUIUtil.setColor(ColorUtil.blueColor);
		JScrollPane sp = new JScrollPane(t);
		JPanel pSubmit = new JPanel();
		pSubmit.add(bAdd);
		pSubmit.add(bEdit);
		pSubmit.add(bDelete);

		this.setLayout(new BorderLayout());
		this.add(sp,BorderLayout.CENTER);
		this.add(pSubmit,BorderLayout.SOUTH);

		//���Ӽ�����
		addListener();
	}
	
	public static void main(String[] args){
		GUIUtil.showPanel(BackupPanel.instance);
	}
	public User getSelectUser(){
		int index = t.getSelectedRow();
		return (User) ctm.cs.get(index);
	}
	@Override
	public void updateDate() {
		// TODO Auto-generated method stub

		ctm.cs = UserDao.all();
		t.updateUI();
		t.getSelectionModel().setSelectionInterval(0, 0);
		if( 0 == ctm.cs.size()){
			bEdit.setEnabled(false);
			bDelete.setEnabled(false);
		}else{
			bEdit.setEnabled(true);
			bDelete.setEnabled(true);
		}
		
	}
	
	@Override
	public void addListener() {
		BackupListener listener = new BackupListener();
		bAdd.addActionListener(listener);
		bEdit.addActionListener(listener);
		bDelete.addActionListener(listener);
	}
	
}
