# Hutuzhang
http://how2j.cn/ 上的一本糊涂账实现项目

1.该项目为J2SE的实践项目,一类pc端账本软件.        

2.没有使用Maven        

3.使用数据库为mysql        

4.环境:jdk1.8.0_141 win10 Eclipse mysql
